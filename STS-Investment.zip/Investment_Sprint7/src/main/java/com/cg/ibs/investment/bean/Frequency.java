package com.cg.ibs.investment.bean;

public enum Frequency {
MONTHLY, QUATERLY, HALFYEARLY, YEARLY,DAILY,ANNUALLY
}
