package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.cg.ibs.investment.bean.Transaction;
@Repository("transactionDao")
public class TransactionDaoImpl implements TransactionDao {
	@PersistenceContext
	private EntityManager entityManager;


	public Transaction addTransaction(Transaction trxn) {
		entityManager.persist(trxn);
		return trxn;
	}

	public List<Transaction> getAllTransactionByAccno(BigInteger accno) {
		CriteriaQuery<Transaction> query = entityManager.getCriteriaBuilder().createQuery(Transaction.class);
		Root<Transaction> root = query.from(Transaction.class);
		query.select(root);

		return entityManager.createQuery(query).getResultList();
	}

}
