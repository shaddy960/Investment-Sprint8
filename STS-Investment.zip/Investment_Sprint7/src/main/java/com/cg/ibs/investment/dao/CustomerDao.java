package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.investment.bean.Customer;

public interface CustomerDao {

	Customer addCustomer(Customer cust);

	Customer updateCustomer(Customer cust);

	Customer getCustByUci(BigInteger uci);

	List<Customer> getAllCustomers();

	boolean removeCustomer(BigInteger uci);
	
	BigInteger getUciByUserId(String userId);

}
