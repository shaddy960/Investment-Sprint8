package com.cg.ibs.investment.bean;

public enum ApplicationStatus {
	PENDING, APPROVED, DENIED;
}
