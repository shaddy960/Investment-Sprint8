package com.cg.ibs.investment.model;

public class WithdrawDir {
	private Integer  folioNumber;
	private Double units;
	private Boolean bool; 
	public Integer getFolioNumber() {
		return folioNumber;
	}
	public void setFolioNumber(Integer folioNumber) {
		this.folioNumber = folioNumber;
	}
	public Double getUnits() {
		return units;
	}
	public void setUnits(Double units) {
		this.units = units;
	}
	public Boolean getBool() {
		return bool;
	}
	public void setBool(Boolean bool) {
		this.bool = bool;
	}
	
	
	

}
