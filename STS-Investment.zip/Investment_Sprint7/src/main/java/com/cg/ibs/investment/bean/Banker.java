package com.cg.ibs.investment.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Bankers")
@NamedQueries({
	@NamedQuery(name = "GET_banker", query = "select t from Banker t where t.userId= :userId ") })
public class Banker {
	@Id
	@Column(name = "banker_id")
	private Integer bankerId;
	@Column(name = "user_id")
	private String userId;
	@Column(name = "password")
	private String password;
	
	public Integer getBankerId() {
		return bankerId;
	}
	public void setBankerId(Integer bankerId) {
		this.bankerId = bankerId;
	}
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
