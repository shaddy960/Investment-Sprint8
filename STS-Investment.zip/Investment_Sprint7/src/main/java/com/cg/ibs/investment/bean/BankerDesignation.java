package com.cg.ibs.investment.bean;

public enum BankerDesignation {
	ADMIN, BANK_EXECUTIVE
}
