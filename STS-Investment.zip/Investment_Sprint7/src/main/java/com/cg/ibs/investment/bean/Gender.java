package com.cg.ibs.investment.bean;

public enum Gender {
	PREFER_NOT_TO_SAY, MALE, FEMALE;
}
