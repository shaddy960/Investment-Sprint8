import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoveMfComponent } from './remove-mf.component';

describe('RemoveMfComponent', () => {
  let component: RemoveMfComponent;
  let fixture: ComponentFixture<RemoveMfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveMfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveMfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
