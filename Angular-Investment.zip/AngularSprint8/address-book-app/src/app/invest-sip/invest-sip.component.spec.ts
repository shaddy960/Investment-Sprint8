import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvestSIPComponent } from './invest-sip.component';

describe('InvestSIPComponent', () => {
  let component: InvestSIPComponent;
  let fixture: ComponentFixture<InvestSIPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvestSIPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvestSIPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
