import { Component, OnInit } from '@angular/core';
import { Statement } from '../model/statement';
import { BankMutualFund } from '../model/bankmutualfund';
import { MutualFund } from '../model/mutualfund';
import { CustomerService } from '../service/customer.service';
import { SipData } from '../model/sipdata';
import { Router } from '@angular/router';

@Component({
  selector: 'app-invest-sip',
  templateUrl: './invest-sip.component.html',
  styleUrls: ['./invest-sip.component.css']
})
export class InvestSIPComponent implements OnInit {
  stmt: Statement;
  mutualFund:MutualFund;
  msg: String;
  mfList:BankMutualFund[];
  dobStr: string;
  sipData:SipData;

  
  constructor(private custServ: CustomerService, private router:Router) {
    this.sipData= new SipData();
    this.stmt = new Statement();
    this.mutualFund= new MutualFund();
   }

  ngOnInit() {
    this.custServ.viewSipPlanCust().subscribe(
      (data)=>{
        this.mfList=data

      }
    )

  }
  investSip(){
    console.log("Here in Invest Sip");
    console.log(this.mutualFund);
    this.mutualFund.openingDate= new Date(this.dobStr);
    this.sipData.mutualFund= this.mutualFund;
    this.custServ.investSipCust(this.sipData).subscribe(
      (data) => {
        this.stmt = data;
        this.msg = data.msg;
        this.custServ.customerMessage=data.msg;
        if(this.stmt.bool){
          this.router.navigate(['/custDash']);
        }else{
          this.custServ.customerError=data.msg;
          this.router.navigate(['/errorCustomer']);
        }
        
      },
      (error)=>{
       this.custServ.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );
  }

}
