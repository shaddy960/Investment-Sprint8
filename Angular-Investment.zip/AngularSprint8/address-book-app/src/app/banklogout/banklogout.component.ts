import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-banklogout',
  templateUrl: './banklogout.component.html',
  styleUrls: ['./banklogout.component.css']
})
export class BanklogoutComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  onDashBoard(){
    this.router.navigate(['/bankMenu']);

  }
  onLogOut(){
    this.router.navigate(['']);

  }
}
