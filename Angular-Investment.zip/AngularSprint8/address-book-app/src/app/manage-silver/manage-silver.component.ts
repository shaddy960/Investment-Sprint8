import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../service/bank-service.service';
import {  Units } from '../model/units';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-silver',
  templateUrl: './manage-silver.component.html',
  styleUrls: ['./manage-silver.component.css']
})
export class ManageSilverComponent implements OnInit {
  sUnits:Units;
  prmsg:String;
  sPrice:Number;
  constructor(private service:BankServiceService, private router:Router) { 
    this.sUnits=new Units();
    this.prmsg;
  }

  ngOnInit() {
    this.service.getSilverPrice().subscribe((data)=>{
      this.sPrice=data.units
          });
  }
  
  updateSPrice(){
    
    console.log(this.sUnits);
    this.service.updateSPrice(this.sUnits).subscribe(
      (data)=>{
        this.prmsg=data.msg
      },
    (err)=>{
      this.service.bankError=err.msg;
      this.router.navigate(['/errorBank']);
    }

      );

    
  }
}
