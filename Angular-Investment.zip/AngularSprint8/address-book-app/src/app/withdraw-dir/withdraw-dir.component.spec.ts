import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawDirComponent } from './withdraw-dir.component';

describe('WithdrawDirComponent', () => {
  let component: WithdrawDirComponent;
  let fixture: ComponentFixture<WithdrawDirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WithdrawDirComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WithdrawDirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
