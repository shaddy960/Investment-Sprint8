import { Component, OnInit } from '@angular/core';
import { MutualFund } from '../model/mutualfund';
import { CustomerService } from '../service/customer.service';
import { WithdrawDir } from '../model/withdrawdir';
import { Statement } from '../model/statement';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw-dir',
  templateUrl: './withdraw-dir.component.html',
  styleUrls: ['./withdraw-dir.component.css']
})
export class WithdrawDirComponent implements OnInit {
  DirFunds:MutualFund[];
  withdr:WithdrawDir;
  stmt:Statement;

  constructor(private custSer:CustomerService, private router:Router) { 
    this.DirFunds=[];
    this.withdr=new WithdrawDir();
    this.stmt=new Statement();
  }

  ngOnInit() {
    this.getActDir();
    this.stmt.msg="Hello";
    this.withdr.bool=false;
  }

  getActDir(){
    this.custSer.getInv().subscribe(
      (data)=>this.DirFunds=data.dirFunds
    );
  }
  withdrawDir(){
    console.log("here");
    this.custSer.withdrawDirMeth(this.withdr).subscribe(
      (data)=>{
        this.stmt=data;
        this.custSer.customerMessage=data.msg;
        if(this.stmt.bool){
          this.router.navigate(['/custDash']);
        }else{
          this.custSer.customerError=data.msg;
          this.router.navigate(['/errorCustomer']);
        }
        
      },
      (error)=>{
       this.custSer.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );
  }

}
