import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { Statement } from '../model/statement';

@Component({
  selector: 'app-error-customer',
  templateUrl: './error-customer.component.html',
  styleUrls: ['./error-customer.component.css']
})
export class ErrorCustomerComponent implements OnInit {
  message:String;
 
  constructor(private custSrv:CustomerService, private router:Router) {
    
   }

  ngOnInit() {
    this.message=this.custSrv.customerError;
  }

}
