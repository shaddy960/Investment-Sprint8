import { MutualFund } from './mutualfund';

export class SipData{
    public  mfPlanId:Number;
	public  mutualFund:MutualFund;
}