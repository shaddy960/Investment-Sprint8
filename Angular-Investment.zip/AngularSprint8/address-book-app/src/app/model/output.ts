export class Output{
    public msg:String;
    public bool:Boolean;
    public mfPlanId:Number;
    public amt:Number;
}