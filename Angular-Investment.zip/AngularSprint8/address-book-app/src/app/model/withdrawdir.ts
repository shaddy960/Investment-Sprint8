export class WithdrawDir{
    public  folioNumber:Number;
	public units:Number;
	public  bool:Boolean; 
}