import { BankMutualFund } from './bankmutualfund';

export class MutualFund{
   
	public folioNumber:Number;
	
	public planName:String;
			
	public  mfUnits:Number;

	public mfAmount:Number;
	
	public openingDate:Date;
	
	public closingDate:Date;
	
	public  duration:Number;
	
	public installments:Number;
	
	public frequency:String;
	
	public  status:Boolean;
	
	public type:String;
	
	public nextInstallDate:Date;
	
	public  buyDate:Date;
	
	public inv:Number;
} 