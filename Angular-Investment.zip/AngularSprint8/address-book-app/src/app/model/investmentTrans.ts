export class InvestmentTrans {
    public transactionId:Number;
    public transactionType:String;
    public transactionDate:Date;
    public transactionAmount:Number;
    public transactionMode:String;
    public transactionDescription:String;
    public transactionBalance:Number;
    public accountNumber:Number;
    public pricePerUnits:Number;
    public units:Number;

        
}