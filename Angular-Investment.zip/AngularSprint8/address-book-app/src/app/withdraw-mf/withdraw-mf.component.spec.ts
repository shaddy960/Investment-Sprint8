import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawMFComponent } from './withdraw-mf.component';

describe('WithdrawMFComponent', () => {
  let component: WithdrawMFComponent;
  let fixture: ComponentFixture<WithdrawMFComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WithdrawMFComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WithdrawMFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
