import { Component, OnInit } from '@angular/core';
import { BankMutualFund } from '../model/bankmutualfund';
import { BankServiceService } from '../service/bank-service.service';
import { Output } from '../model/output';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-mf',
  templateUrl: './view-mf.component.html',
  styleUrls: ['./view-mf.component.css']
})
export class ViewMfComponent implements OnInit {
  bankmut:BankMutualFund[];
  msg:String;
  out:Output;
  constructor(private banksrv:BankServiceService, private router:Router) { 
    this.bankmut=[];
    this.out=new Output();
    this.msg="";
    
  }

  ngOnInit() {
    this.getMf();
  }
  getMf(){
    this.banksrv.getAllMfs().subscribe(
      (data)=>this.bankmut=data,
      
    (err)=>{
      this.banksrv.bankError=err.msg;
      this.router.navigate(['/errorBank']);
    }

    );
  }
  onGoBack(){
    this.router.navigate(['/manageMf'])
  }

}
