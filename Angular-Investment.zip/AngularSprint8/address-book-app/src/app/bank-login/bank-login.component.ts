import { Component } from '@angular/core';
import {BankLogin } from '../model/bank-login';
import {BankServiceService} from '../service/bank-service.service';
import { Statement } from '../model/statement';
import { User } from '../model/user';
import { Router } from '@angular/router';


@Component({
  selector: 'app-bank-login',
  templateUrl: './bank-login.component.html',
  styleUrls: ['./bank-login.component.css']
})
export class BankLoginComponent  {
  
  user:User;
  message:String;
  stmt: Statement;

  
  
  constructor(private bankservice:BankServiceService, private router:Router) {
    this.user=new User();
    this.stmt=new Statement();
  }
  bnklgn(){
    this.bankservice.loginBank(this.user).subscribe(
      (data)=>{
        this.message=data.msg;
        this.stmt.bool=data.bool;
        if (this.stmt.bool) {
          this.message = this.user.userId;
          this.router.navigate(['/Bank']);
       } else {
          this.message = "Failure";
        } 
      },
      (error)=>{
        this.message=error;
      }
    );
  }
}

