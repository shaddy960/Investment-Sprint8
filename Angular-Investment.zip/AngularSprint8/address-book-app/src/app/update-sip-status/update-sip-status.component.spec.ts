import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSipStatusComponent } from './update-sip-status.component';

describe('UpdateSipStatusComponent', () => {
  let component: UpdateSipStatusComponent;
  let fixture: ComponentFixture<UpdateSipStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateSipStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateSipStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
