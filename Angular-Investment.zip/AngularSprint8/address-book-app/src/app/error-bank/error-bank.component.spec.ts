import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorBankComponent } from './error-bank.component';

describe('ErrorBankComponent', () => {
  let component: ErrorBankComponent;
  let fixture: ComponentFixture<ErrorBankComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErrorBankComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
