import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { User } from '../model/user';
import { environment } from 'src/environments/environment.prod';
import { Observable, throwError } from 'rxjs';
import { ViewInvestment } from '../model/viewInvestment';

  import {Statement} from '../model/statement';
import { Units } from '../model/units';
import { Directdata } from '../model/directdata';
import { BankMutualFund } from '../model/bankmutualfund';
import { MutualFund } from '../model/mutualfund';
import { SipData } from '../model/sipdata';
import { InvestmentTrans } from '../model/investmentTrans';
import { WithdrawDir } from '../model/withdrawdir';
import {catchError} from 'rxjs/operators';
import { ViewAccount } from '../model/viewAccount';





@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  user1:User;

  customerError:String;
  customerMessage:String;
  baseUrl: string;
  viewInvUrl:string;
  buyGold:string;
  sellGold:string;
  buySilver:string;
  sellSilver:string;
  investDirect:string;
  viewDirPlan:string;
  viewSipPlan:string;
  investSip:string;
  viewTrans:string;
  withdrawDir:string;
  withdrawSip:string;
  result: Observable<String>;
  getAccs:string;
  linkAc:string;
  constructor(private http: HttpClient) { 
    this.baseUrl =`${environment.baseMwUrl}/customer/login`;
    this.viewInvUrl =`${environment.baseMwUrl}/customer/viewMyInvestment`;
    this.buyGold=`${environment.baseMwUrl}/customer/buyGold`;
    this.sellGold=`${environment.baseMwUrl}/customer/sellGold`;
    this.buySilver=`${environment.baseMwUrl}/customer/buySilver`;
    this.sellSilver=`${environment.baseMwUrl}/customer/sellSilver`;
    this.investDirect=`${environment.baseMwUrl}/customer/directInvest`;
    this.viewDirPlan=`${environment.baseMwUrl}/customer/viewDirectMf`;
    this.viewSipPlan=`${environment.baseMwUrl}/customer/viewSipMf`;
    this.investSip=`${environment.baseMwUrl}/customer/investSipMf`;
    this.viewTrans=`${environment.baseMwUrl}/customer/viewTrans`;
    this.withdrawDir=`${environment.baseMwUrl}/customer/withdrawDirMf`;
    this.withdrawSip=`${environment.baseMwUrl}/customer/withdrawSipMf`;
    this.getAccs=`${environment.baseMwUrl}/customer/accountList`;
    this.linkAc=`${environment.baseMwUrl}/customer/linkAccount`;
    this.customerMessage="Welcome to Customer DashBoard";
    this.customerError="Somethimg Went Wrong";
  }
  authenticate(user:User): Observable<Statement>{
    this.user1 = user;
       return this.http.post<Statement>(this.baseUrl,user).pipe(catchError(this.errorHandler));
    

  }

  authenticateUser(userId){
  
      sessionStorage.setItem('userId',userId);
     
          
  }

  isUserLoggedIn() {
    let userr = sessionStorage.getItem('userId')
    console.log(!(userr === null))
    return !(userr === null)
  }

  logOut() {
    sessionStorage.removeItem('userId')
  }

 
  getInv():Observable<ViewInvestment>{
    return this.http.get<ViewInvestment>(this.viewInvUrl).pipe(catchError(this.errorHandler));
  }
  getAccounts():Observable<ViewAccount[]>{
    console.log("here in service");
    return this.http.get<ViewAccount[]>(this.getAccs).pipe(catchError(this.errorHandler));
  }


  buyCustGold(gunits:Units):Observable<Statement>{
    console.log(gunits.units)
    return this.http.post<Statement>(this.buyGold,gunits).pipe(catchError(this.errorHandler));
  }
  sellCustGold(gunits:Units):Observable<Statement>{
    return this.http.post<Statement>(this.sellGold,gunits).pipe(catchError(this.errorHandler));
  }

  buyCustSilver(sunits:Units):Observable<Statement>{
    console.log(sunits.units)
    return this.http.post<Statement>(this.buySilver,sunits).pipe(catchError(this.errorHandler));

  }
  sellCustSilver(sunits:Units):Observable<Statement>{
    return this.http.post<Statement>(this.sellSilver,sunits).pipe(catchError(this.errorHandler));
  }

  investDirectCust(directdata:Directdata):Observable<Statement>{
    return this.http.post<Statement>(this.investDirect,directdata).pipe(catchError(this.errorHandler));
  }
  viewDirPlanCust():Observable<BankMutualFund[]>{
    return this.http.get<BankMutualFund[]>(this.viewDirPlan).pipe(catchError(this.errorHandler));
  }
  viewSipPlanCust():Observable<BankMutualFund[]>{
    return this.http.get<BankMutualFund[]>(this.viewSipPlan).pipe(catchError(this.errorHandler));
  }
  investSipCust(sipdata:SipData):Observable<Statement>{
    return this.http.post<Statement>(this.investSip,sipdata).pipe(catchError(this.errorHandler));
  }
  getAllTrans():Observable<InvestmentTrans[]>{
    return this.http.get<InvestmentTrans[]>(this.viewTrans).pipe(catchError(this.errorHandler));
  }
  withdrawDirMeth(withdr:WithdrawDir):Observable<Statement>{
    return this.http.post<Statement>(this.withdrawDir, withdr).pipe(catchError(this.errorHandler));
  }
  withdrawSipMeth(withsp:WithdrawDir):Observable<Statement>{
    return this.http.post<Statement>(this.withdrawSip, withsp).pipe(catchError(this.errorHandler));
  }

  linkMyAccount(units:Units):Observable<Statement>{
    return this.http.post<Statement>(this.linkAc,units).pipe(catchError(this.errorHandler));
  }
  errorHandler(error:HttpErrorResponse){
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
    } else {
     
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      error.error);
  }
  



}
