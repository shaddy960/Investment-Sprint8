import { Component, OnInit } from '@angular/core';
import { BankMutualFund } from '../model/bankmutualfund';
import { BankServiceService } from '../service/bank-service.service';
import { Output } from '../model/output';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-min-amt-sip',
  templateUrl: './update-min-amt-sip.component.html',
  styleUrls: ['./update-min-amt-sip.component.css']
})
export class UpdateMinAmtSipComponent implements OnInit {

  bankmut:BankMutualFund[];
  msg:String;
  out:Output;
  constructor(private banksrv:BankServiceService,private router:Router) { 
    this.bankmut=[];
    this.out=new Output();
    this.msg="";
    
  }

  ngOnInit() {
    this.getMf();
  }
  getMf(){
    this.banksrv.getAllMfs().subscribe(
      (data)=>this.bankmut=data
    );
  }
  updateSipAmount(){
    
    this.banksrv.updateSipAmt(this.out).subscribe(
      (data)=>{
        this.msg=data.msg;
        this.banksrv.bankMessage=data.msg;
        this.out.bool=data.bool;
        if(this.out.bool){         
          this.router.navigate(['/Bank']);
        }else{
          this.banksrv.bankError=data.msg;
          this.router.navigate(['/errorBank']);
        }     
      },
      (err)=>{
        this.banksrv.bankError=err.msg;
        this.router.navigate(['/errorBank']);
      }


    );
  }

}
