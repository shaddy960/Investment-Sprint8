import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewinvestmentsComponent } from './viewinvestments.component';

describe('ViewinvestmentsComponent', () => {
  let component: ViewinvestmentsComponent;
  let fixture: ComponentFixture<ViewinvestmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewinvestmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewinvestmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
