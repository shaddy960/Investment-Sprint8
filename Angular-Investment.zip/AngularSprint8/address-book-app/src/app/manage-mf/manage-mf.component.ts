import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-mf',
  templateUrl: './manage-mf.component.html',
  styleUrls: ['./manage-mf.component.css']
})
export class ManageMfComponent implements OnInit {

  constructor(private router:Router) { 

  }

  ngOnInit() {
  }

  viewMF(){
    this.router.navigate(['/addMf']);
  }
  updateNav(){
    this.router.navigate(['/updateNav']);
  }
  updateDirSt(){
    this.router.navigate(['/updateDirStatus']);
  }
  updateSipSt(){
    this.router.navigate(['/updateSipStatus']);
  }
  updateMinDir(){
    this.router.navigate(['/updateMinAmtDir']);
  }
  updateMinSip(){
    this.router.navigate(['/updateMinAmtSip']);
  }
  removeMf(){
    this.router.navigate(['/removeMf']);
  }

}
